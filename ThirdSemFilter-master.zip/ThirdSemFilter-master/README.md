
### Task: 1 for FOS club
1. Create a github account
2. Fork this repository
3. Add your name in the name section of your *SRN* in  the people.json file
4. Commit changes and submit a PR
